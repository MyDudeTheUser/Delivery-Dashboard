document.addEventListener("DOMContentLoaded", function() {
    fetch("data/system_health.json")
        .then(response => response.json())
        .then(data => {
            document.getElementById("system-health").innerText = "System Health: " + JSON.stringify(data);
        });

    fetch("data/alerts.json")
        .then(response => response.json())
        .then(data => {
            document.getElementById("alerts").innerText = "Alerts: " + JSON.stringify(data);
        });

    fetch("data/sprint_status.csv")
        .then(response => response.text())
        .then(data => {
            document.getElementById("sprint-status").innerText = "Sprint Status:
" + data;
        });
});
